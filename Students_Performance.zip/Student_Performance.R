##### A web application that offers various visualisation tools.
##### To help users understand the factors that could affect a child's test scores
##### created by: Rayner Lim Fang Yuh ###### 

data(students)
library(dplyr)          ### data manipulation
library(ggplot2)        ### data visualisation
library(shiny)          ### to build/run the shiny app
library(shinythemes)    ### creating the theme of the shiny app

ui <- fluidPage(theme = shinytheme("united"),
                navbarPage("Student Performance Web App",
                           
                  tabPanel("Histograms",      # first tab
                    sidebarLayout(
                      sidebarPanel(
                        h1("Student Performance"),
                        h2("What affects students' test scores?"),
                        h3("The purpose of this app is to find out what variables affect a student's
                            test scores (writing, reading, math)"),
                        tags$br(),
                        p("First we will take a look at the histograms of each test score. This will 
                          allow us to see if their distibutions are normal, in order to perform a linear
                          regression analysis. Adjust the slider to change the number of bins for the 
                          respective histograms."),
                        tags$br(),
                        sliderInput(inputId = "mathbins", label = tags$strong("Number of bins for math score"),
                                    min = 1, max = 20, value = 10),
                        tags$br(),
                        sliderInput(inputId = "wbins", label = tags$strong("Number of bins for writing score"),
                                    min = 1, max = 20, value = 10),
                        tags$br(),
                        sliderInput(inputId = "rbins", label = tags$strong("Number of bins for reading score"),
                                    min = 1, max = 20, value = 10)
                        ),
                      mainPanel(
                        plotOutput(outputId = "mathhist"),
                        plotOutput(outputId = "whist"),
                        plotOutput(outputId = "rhist")
                      )
                    )
                  ),
                  tabPanel("Linear Regression",         # second tab
                    tabsetPanel(
                      tabPanel("Writing VS Reading",    # write VS read
                               sidebarLayout(
                                 sidebarPanel(
                                   h2("Explore the relationship between writing and reading scores"),
                                   checkboxInput(inputId = "checkbox1", label = "Display Regression Line",
                                                 value = FALSE),
                                   p("We can see a very strong linear relationship between writing and 
                                     reading scores")
                                 ),
                                 mainPanel(
                                   plotOutput(outputId = "w_vs_r")
                                 )
                               )
                      ),
                      tabPanel("Reading VS Math",      # read VS math
                               sidebarLayout(
                                 sidebarPanel(
                                   h2("Explore the relationship between reading and math scores"),
                                   checkboxInput(inputId = "checkbox2", label = "Display Regression Line",
                                                 value = FALSE),
                                   p("We can see a very strong linear relationship between reading and 
                                     math scores")
                                 ),
                                 mainPanel(
                                   plotOutput(outputId = "r_vs_m")
                                 )
                               )
                            ),
                      tabPanel("Writing VS Math",     # write VS math
                               sidebarLayout(
                                 sidebarPanel(
                                   h2("Explore the relationship between writing and math scores"),
                                   checkboxInput(inputId = "checkbox3", label = "Display Regression Line",
                                                 value = FALSE),
                                   p("We can see a very strong linear relationship between writing and 
                                     math scores")
                                 ),
                                 mainPanel(
                                   plotOutput(outputId = "w_vs_m")
                                 )
                               )
                          ),
                      tabPanel("Other Factors",
                               sidebarLayout(
                                 sidebarPanel(
                                   radioButtons(inputId = "radio1", label = "Choose a variable",
                                                choices = list("race/ethnicity", "parental level of education",
                                                               "lunch type", "test preparation course"),
                                                selected = "test preparation course")
                                 ),
                                 mainPanel(
                                   plotOutput(outputId = "boxplot1", height = 600)
                                 )
                               )
                            )
                    )       
                  ),
                  tabPanel("References",        # third tab
                           "The dataset can be downloaded",
                           tags$a(href = "https://www.kaggle.com/datasets/spscientist/students-performance-in-exams", "here"),
                           p("*** Disclaimer *** The owner of this dataset has stated explicitly that all 
                             data recorded was fictional. This app is only meant for users to have fun and 
                             also for me to display my skills. It should not be used for any research purposes."))
               )
          )

server <- function(input, output){
  output$mathhist <- renderPlot({  # display math histogram
    mathscore <- students$math.score
    bins <- seq(min(mathscore), max(mathscore), length.out = input$mathbins+1)
    hist(mathscore, breaks = bins, xlab = "Math Score", main = "Histogram of Math Test Scores", col = "lightblue")
  })
  output$whist <- renderPlot({     # display writing histogram
    wscore <- students$writing.score
    bins <- seq(min(wscore), max(wscore), length.out = input$wbins+1)
    hist(wscore, breaks = bins, xlab = "Writing Score", main = "Histogram of Writing Test Scores", col = "lightblue")
  })
  output$rhist <- renderPlot({     # display reading histogram
    rscore <- students$reading.score
    bins <- seq(min(rscore), max(rscore), length.out = input$rbins+1)
    hist(rscore, breaks = bins, xlab = "Reading Score", main = "Histogram of Reading Test Scores", col = "lightblue")
  })
  
  output$w_vs_r <- renderPlot({    # write VS read
    if (input$checkbox1 == TRUE){  # superimpose regression line onto scatter plot
      ggplot(students, aes(x = writing.score, y = reading.score))+geom_point()+
        labs(x = "Writing Score", y = "Reading Score", title = "Writing VS Reading")+
        theme_bw()+
        theme(plot.title = element_text(size = 20, hjust = 0.5),
              axis.title = element_text(size = 14))+
        geom_smooth(method = lm, se = FALSE)
    } else {     # display scatter plot
      ggplot(students, aes(x = writing.score, y = reading.score))+geom_point()+
        labs(x = "Writing Score", y = "Reading Score", title = "Writing VS Reading")+
        theme_bw()+
        theme(plot.title = element_text(size = 20, hjust = 0.5),
              axis.title = element_text(size = 14))
    }
  })
  
  output$r_vs_m <- renderPlot({    # read VS math
    if (input$checkbox2 == TRUE){  # superimpose regression line onto scatter plot
      ggplot(students, aes(x = reading.score, y = math.score))+geom_point()+
        labs(x = "Reading Score", y = "Math Score", title = "Reading VS Math")+
        theme_bw()+
        theme(plot.title = element_text(size = 20, hjust = 0.5),
              axis.title = element_text(size = 14))+
        geom_smooth(method = lm, se = FALSE)
    } else {     # display scatter plot
      ggplot(students, aes(x = reading.score, y = math.score))+geom_point()+
        labs(x = "Reading Score", y = "Math Score", title = "Reading VS Math")+
        theme_bw()+
        theme(plot.title = element_text(size = 20, hjust = 0.5),
              axis.title = element_text(size = 14))
    }
  })
  
  output$w_vs_m <- renderPlot({    # write VS math
    if (input$checkbox3 == TRUE){  # superimpose regression line onto scatter plot
      ggplot(students, aes(x = writing.score, y = math.score))+geom_point()+
        labs(x = "Writing Score", y = "Math Score", title = "Writing VS Math")+
        theme_bw()+
        theme(plot.title = element_text(size = 20, hjust = 0.5),
              axis.title = element_text(size = 14))+
        geom_smooth(method = lm, se = FALSE)
    } else {     # display scatter plot
      ggplot(students, aes(x = writing.score, y = math.score))+geom_point()+
        labs(x = "Writing Score", y = "Math Score", title = "Writing VS Math")+
        theme_bw()+
        theme(plot.title = element_text(size = 20, hjust = 0.5),
              axis.title = element_text(size = 14))
    }
  })
  
  output$boxplot1 <- renderPlot({        # boxplot
    if (input$radio1 == "test preparation course"){
      ggplot(students, aes(x = gender, y = ave_score, color = test.preparation.course))+geom_boxplot()+theme_bw()+
      labs(title = "Boxplot", x = "Gender", y = "Average Test Score")+
      theme(plot.title = element_text(size = 20, hjust = 0.5),
            axis.title = element_text(size = 14))
    } else if (input$radio1 == "race/ethnicity"){
      ggplot(students, aes(x = gender, y = ave_score, color = race.ethnicity))+geom_boxplot()+theme_bw()+
      labs(title = "Boxplot", x = "Gender", y = "Average Test Score")+
      theme(plot.title = element_text(size = 20, hjust = 0.5),
            axis.title = element_text(size = 14))
    } else if (input$radio1 == "parental level of education"){
      ggplot(students, aes(x = gender, y = ave_score, color = parental.level.of.education))+geom_boxplot()+theme_bw()+
      labs(title = "Boxplot", x = "Gender", y = "Average Test Score")+
      theme(plot.title = element_text(size = 20, hjust = 0.5),
            axis.title = element_text(size = 14))
    } else if (input$radio1 == "lunch type"){
      ggplot(students, aes(x = gender, y = ave_score, color = lunch))+geom_boxplot()+theme_bw()+
      labs(title = "Boxplot", x = "Gender", y = "Average Test Score")+
      theme(plot.title = element_text(size = 20, hjust = 0.5),
            axis.title = element_text(size = 14))
    }
  })
}

shinyApp(ui = ui, server = server)