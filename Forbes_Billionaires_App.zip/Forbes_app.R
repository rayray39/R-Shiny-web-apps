### FORBES LIST OF BILLIONAIRES WEB APPLICATION ###
### created by: Rayner Lim Fang Yuh ###

library(shiny)          ### running/building the shiny app
library(shinythemes)    ### creating the theme of the shiny app 
library(ggplot2)        ### for plotting of graphs (histogram, barplot and scatter plot)

### these are the data sets that you should have downloaded from the zipped file, in order for the app to run 
data(forbes_dataset)
data(sg_rich_dataset)
data(usa_dataset)
data(germany_dataset)
data(china_dataset)

### output1 == description of graph
### plot1 == rendered plot in main panel, in main tab
### big3 == plot output for one of selected graph (usa, germany, china)

ui <- fluidPage(theme = shinytheme("flatly"),
      titlePanel("Forbes Billionaires In 2022"),
  tabsetPanel(
    tabPanel("Main Tab",
      sidebarLayout(
        sidebarPanel(
          h3("This webapp shows information regarding Forbes list of billionaires in 2022."),
          p("The total number of billionaires in this dataset is 2600."),
          selectInput("graph", label = h5("select a graph to view:"), choices = c("Billionaires by Industry","Singapore's Richest")),
          textOutput("output1"),        # description of graph
        ),
        mainPanel(
          plotOutput("plot1", width = "900", height = "600", click = "on_click"),      # graph plotted
          verbatimTextOutput("info")         ### displays the point the user clicked on
        )
      )
    ),
    tabPanel("The Big 3",
             sidebarLayout(
               sidebarPanel(
                 h3("This tab features the 3 countries with the highest number of billionaires (United States, Germany and China)."),
                 p("Navigate using the radio buttons below to view the specific country's barplot"),
                 radioButtons("radio", label = h5("select the country below:"), choices = list("United States"=1, "Germany"=2, "China"=3))
               ),
               mainPanel(plotOutput("big3", width = "900", height = "600"))
             )
          ),
    tabPanel("References", 
             tags$h5("The data set was downloaded ",
                     tags$a(href = "https://www.kaggle.com/datasets/jjdaguirre/forbes-billionaires-2022","here"),
                   )
    )
  )
)

server <- function(input, output){
  output$plot1 <- renderPlot({
    if (input$graph == "Singapore's Richest"){
      ggplot(sg_rich_dataset, aes(x=Age, y=Networth))+geom_point()+
      labs(title = "Singapore's Bling Empire, Networth VS Age", y = "Networth (in billions)")+
      theme(plot.title = element_text(size = 14, hjust = 0.5),
            axis.title = element_text(size = 12))
      
    } else if (input$graph == "Billionaires by Industry"){
      ggplot(forbes_dataset, aes(x=Industry))+geom_bar()+
      theme(axis.text.x = element_text(angle = 70, vjust = 0.5, size = 11),
      plot.title = element_text(hjust = 0.5, size = 14),
      panel.background = element_rect(fill = "white"), panel.grid = element_line(color = "grey"),
      axis.title = element_text(size = 12))+
      labs(title = "Number Of Billionaires By Industry", y = "Count", x = "Industry")
    }
  })
  output$output1 <- renderText({
    if (input$graph == "Singapore's Richest"){
      paste("The scatter plot shows Singapore's billionaires, with their networth as the dependent variable(Y)
            and age as the independent variable(X).", "Click on a point on the graph to view its coordinates.")
    } else if (input$graph == "Billionaires by Industry"){
      paste("The barplot shows the number of billionaires in each indusry, with industry on the X-axis and 
            count on the Y-axis.")
    }
  })
  output$info <- renderPrint({
    if (input$graph == "Singapore's Richest"){
      age_networth_str <- function(r){
        if ( is.null(r) ){
          return("Null")
        } else {
          paste("Age = ", round(r$x, 0), "Networth = ", round(r$y, 3))
        }
      }
      paste("displayed point: ", age_networth_str(input$on_click))
    }
  })
  output$big3 <- renderPlot({
    if (input$radio == 1){
      ggplot(usa_dataset, aes(x=Industry))+geom_bar()+
      theme(axis.text.x = element_text(vjust = 0.5, angle = 70, size = 11), 
            axis.title = element_text(size = 12),
            plot.title = element_text(size = 14, hjust = 0.5),
            panel.background = element_rect(fill = "white"),
            panel.grid = element_line(color = "grey"))+
      labs(title = "United States")
    } else if (input$radio == 2){
      ggplot(germany_dataset, aes(x=Industry))+geom_bar()+
      theme(axis.text.x = element_text(vjust = 0.5, angle = 70, size = 11), 
            axis.title = element_text(size = 12),
            plot.title = element_text(size = 14, hjust = 0.5),
            panel.background = element_rect(fill = "white"),
            panel.grid = element_line(color = "grey"))+
        labs(title = "Germany")
    } else if (input$radio == 3){
      ggplot(china_dataset, aes(x=Industry))+geom_bar()+
      theme(axis.text.x = element_text(vjust = 0.5, angle = 70, size = 11), 
            axis.title = element_text(size = 12),
            plot.title = element_text(size = 14, hjust = 0.5),
            panel.background = element_rect(fill = "white"),
            panel.grid = element_line(color = "grey"))+
      labs(title = "China")
    }
  })
}
  

shinyApp(ui=ui, server=server)
