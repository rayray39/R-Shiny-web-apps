### Spotify Song Analysis ###
### created by: Rayner Lim Fang Yuh ###

library(shiny)
library(shinythemes)
library(ggplot2)
library(dplyr)
data(spotify)

pops <- select(spotify, artist, song, popularity, year)    # select the 4 columns from spotify and store into new data set called pops
pops <- pops %>% distinct()       # the data set contains repeated songs, which we can remove using distinct()
pops <- pops %>% arrange(desc(popularity))
top_overall <- pops[1:10,]       # get the top 10 songs

after_pops <- filter(pops, year >= 2000)
after_pops <- after_pops %>% distinct()
after_pops <- after_pops %>% arrange(desc(popularity))
after_overall <- after_pops[1:10,]

before_pops <- filter(pops, year < 2000)
before_pops <- before_pops %>% distinct()
before_pops <- before_pops %>% arrange(desc(popularity))
before_overall <- before_pops[1:10,]

ui <- fluidPage(theme = shinytheme("darkly"),
  titlePanel("Spotify Songs"),
  tabsetPanel(
    tabPanel("Main",
      sidebarLayout(
        sidebarPanel(
          tags$h1("Analysis of Spotify Songs"),
          tags$p("This is my attempt at analysing the different attributes of a song, and in the process,
                 I hope to gather some valuable insights about the data."),
          
          tags$p("Adjust the slider below to interactively change the number of bins of the first
                 histogram."),
          sliderInput(inputId = "bins", label = tags$strong("Number Of Bins"), min = 1, max = 30, value = 15),
          tags$br(),
          
          tags$p("The second histogram shows the data set containing songs from year 2000 and after"),
          tags$p("Adjust the slider below to interactively change the number of bins of the second
                 histogram."),
          sliderInput(inputId = "bins2", label = tags$strong("Number of Bins"), min = 1, max = 30, value = 15),
          tags$br(),
          
          tags$p("The third histogram shows the data set containing songs before year 2000"),
          tags$p("Adjust the slider below to interactively change the number of bins of the third
                 histogram."),
          sliderInput(inputId = "bins3", label = tags$strong("Number of Bins"), min = 1, max = 20, value = 10)
        ),
        mainPanel(
          plotOutput(outputId = "spotify_hist"),
          plotOutput(outputId = "after2000_hist"),
          plotOutput(outputId = "before2000_hist")
        )
      )
    ),
    tabPanel("Summary Statistics",
             sidebarLayout(
               sidebarPanel(
                 tags$h1("Summary Statistics"),
                 tags$p("The contents of this tab shows the summary statistics (median, maximum & minimum)
                        of the 3 data sets, with regards to the Popularity score: ", tags$br(), 
                        "1. the entire Overall dataset", tags$br(),
                        "2. the data set containing songs from year 2000 and after", tags$br(),
                        "3. the data set containing songs before year 2000."),
                 tags$p("Click on each tab to find out more about each data set and see the top 10 songs
                        of that data set.")
               ),
               mainPanel(
                 tabsetPanel(
                   tabPanel("Overall", verbatimTextOutput("text1"),
                            tableOutput("top10spotify")),
                   tabPanel("2000 and After", verbatimTextOutput("text2"),
                            tableOutput("top10after")),
                   tabPanel("Before 2000", verbatimTextOutput("text3"),
                            tableOutput("top10before"))
                 )
               )
             )
            ),
    tabPanel("References",
            "The data set was downloaded", tags$a(href = "https://www.kaggle.com/datasets/paradisejoy/top-hits-spotify-from-20002019", "here"))
    )
)


server <- function(input, output){
  output$spotify_hist <- renderPlot({
    x <- spotify$popularity
    bins <- seq(min(x), max(x), length.out = input$bins+1)
    hist(x, breaks = bins, xlab = "Popularity", main = "Histogram of Popularity of Songs",
         xlim = c(0,100), ylim = c(0,600), cex.lab = 1.2, cex.main = 1.5)
  })
  output$after2000_hist <- renderPlot({
    x2 <- after_2000$popularity
    bins <- seq(min(x2), max(x2), length.out = input$bins2+1)
    hist(x2, breaks = bins, xlab = "Popularity", main = "Histogram of Popularity of Songs(after 2000)",
         xlim = c(0,100), ylim = c(0,400), cex.lab = 1.2, cex.main = 1.5)
  })
  output$before2000_hist <- renderPlot({
    x3 <- before_2000$popularity
    bins <- seq(min(x3), max(x3), length.out = input$bins3+1)
    hist(x3, breaks = bins, xlab = "Popularity", main = "Histogram of Popularity of Songs(before 2000)",
         xlim = c(40,100), ylim = c(0,15), cex.lab = 1.2, cex.main = 1.5)
  })
  output$text1 <- renderText({
    paste("Median: ", median(spotify$popularity), sep = "\n",
          "Maximum: ", max(spotify$popularity),
          "Minimum: ", min(spotify$popularity),
          "Total Number of Songs: ", count(spotify))
  })
  output$text2 <- renderText({
    paste("Median: ", median(after_2000$popularity), sep = "\n",
          "Maximum: ", max(after_2000$popularity),
          "Minimum: ", min(after_2000$popularity),
          "Total Number of Songs: ", count(after_2000))
  })
  output$text3 <- renderText({
    paste("Median: ", median(before_2000$popularity), sep = "\n",
          "Maximum: ", max(before_2000$popularity),
          "Minimum: ", min(before_2000$popularity),
          "Total Number of Songs: ", count(before_2000))
  })
  output$top10spotify <- renderTable({
    top_overall
  })
  output$top10after <- renderTable({
    after_overall
  })
  output$top10before <- renderTable({
    before_overall
  })
}

shinyApp(ui = ui, server = server)
