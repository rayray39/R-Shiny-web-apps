### A simple R web app that shows you the usage trends of a few programming languages,
### (python, matlab, C/C++, C#, R, Java, JavaScript), from 2004-2021. The purpose is to 
### offer the user some insight into how the usage of these programming languages have  
### changed and decide on which programming language to learn if they are really unsure.

### Created by Rayner Lim Fang Yuh, NUS Mechanical Engineering

library(shiny)
library(shinythemes)
library(ggplot2)
data(popular_langs)

ui <- fluidPage(theme = shinytheme("cosmo"),
                navbarPage("Popular Programming Languages",
                  tabPanel("Main",
                           sidebarLayout(
                             sidebarPanel(code(h2("Programming Language Usage Over The Years")),
                                          h4("Having trouble deciding which programming language to pick up?"),
                                          p(),
                                          p("This app shows you the usage trends of several popular programming languages from  
                                          2004 - 2021. Hopefully it will help you to decide/predict which programming
                                          language(s) will be in demand and worthwhile to learn."),
                                          p("The 7 programming languages featured in the graph are:"),
                                          tags$ul(tags$li("Python"), tags$li("Matlab"),
                                                  tags$li("C and C++"), tags$li("C#"),
                                                  tags$li("R"), tags$li("Java"),
                                                  tags$li("JavaScript")
                                                  )
                                          ),
                             mainPanel(
                              plotOutput("pop_langs"),
                              plotOutput("total")
                             )
                       )
                  ),
                  tabPanel("References",
                           h4("All references are listed below"),
                           tags$h5("The dataset was downloaded ", 
                                   tags$a(href="https://www.kaggle.com/datasets/muhammadkhalid/most-popular-programming-languages-since-2004?resource=download",
                                          "here")
                                   )
                           ) ## insert relevant references(data)
          )
)

server <- function(input, output){
  output$pop_langs <- renderPlot({
    ggplot(popular_langs, aes(x=Date,group = 1))+geom_line(aes(y=Python, color = "Python"))+
            geom_line(aes(y=Matlab, color = "Matlab"))+
            geom_line(aes(y=C.C.., color = "C and C++"))+
            geom_line(aes(y=C., color = "C#"))+
            geom_line(aes(y=R, color = "R"))+
            geom_line(aes(y=Java,  color = "Java"))+
            geom_line(aes(y=JavaScript, color = "JavaScript"))+
            labs(y = "Usage (%)", x = "Year", title = "Programming Language Usage")+
            theme_bw()+
            scale_color_manual(name = "Legend", values = c("Python"="black", "MATLAB"="green", "C and C++"="cyan",
                                                           "C#"="purple", "R"="chocolate", "Java"="pink",
                                                           "JavaScript"="red3"))
  })
  output$total <- renderPlot({
    ggplot(popular_langs, aes(x=Date, y=Total, group = 1))+geom_line()+
      labs(x = "Year", y = "Total Usage (%)", title = "Total Programming Langauge Usage")+
      theme_bw()
  })
}

shinyApp(ui, server)